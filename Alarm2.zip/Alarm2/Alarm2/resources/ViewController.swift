//
//  ViewController.swift
//  Alarm2
//
//  Created by Ben Brandau Brandau on 1/13/20.
//  Copyright © 2020 Ben Brandau. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

