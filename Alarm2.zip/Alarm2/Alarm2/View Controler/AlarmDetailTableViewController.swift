//
//  AlarmDetailTableViewController.swift
//  Alarm2
//
//  Created by Ben Brandau Brandau on 1/13/20.
//  Copyright © 2020 Ben Brandau. All rights reserved.
//

import UIKit

class AlarmDetailTableViewController: UITableViewController {
    
    
    @IBOutlet weak var DatePicker: UIDatePicker!
    @IBOutlet weak var TitleBar: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func SaveButtonTapped(_ sender: Any) {
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }
    
    
    
}
