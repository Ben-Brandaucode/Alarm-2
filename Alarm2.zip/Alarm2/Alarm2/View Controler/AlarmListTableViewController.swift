//
//  AlarmListTableViewController.swift
//  Alarm2
//
//  Created by Ben Brandau Brandau on 1/13/20.
//  Copyright © 2020 Ben Brandau. All rights reserved.
//

import UIKit

protocol SwitchTableViewCellDelegate:class{
    func alarmSwitchTapped (for cell:AlarmListTableViewController)
}

class AlarmListTableViewController: UITableViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return AlarmController.sharedInstance.alarms.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        let alarm = AlarmController.sharedInstance.alarms[indexPath.row]

        // Configure the cell...gaurd gu

        return cell
    }



  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
 

}
