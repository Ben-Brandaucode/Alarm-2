//
//  AlarmControler.swift
//  Alarm2
//
//  Created by Ben Brandau Brandau on 1/13/20.
//  Copyright © 2020 Ben Brandau. All rights reserved.
//

import Foundation

class AlarmController{
 static let  sharedInstance = AlarmController()
    
    var  alarms : [Alarm] = []
    
    func addAlarm(fireDate:Date, name:String, enabled:Bool ){
        let newAlarm = Alarm(fireDate: fireDate, name: name, enabled: enabled)
        alarms.append(newAlarm)
        
        saveToPersistenceStore()
        
    }
    
    
    func updateAlarm (alarm:Alarm, fireDate:Date, name:String, enabled:Bool){
        alarm.fireDate = fireDate
        alarm.name = name
        alarm.enabled = enabled
        
        saveToPersistenceStore()
        
    }

    func delete(Alarm:Alarm){
        guard let index = alarms.firstIndex(of: Alarm) else {return}
        alarms.remove(at: index)
        
          saveToPersistenceStore()
    
    }
    //Mark: Persistence
    func createFileURLForPersistence() ->URL{
        //grab the users document directory
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        //Create the new file URL on the user's phone
        let fileURL = urls[0].appendingPathComponent("Alarm.json")
        return fileURL
    }
    func saveToPersistenceStore() {
        //create an instance of a JSON Encoder
        let jsonEncoder = JSONEncoder()
        //attempt To Convert our alarms to JSon
        do {
            let jsonAlarm = try jsonEncoder.encode(alarms)
            // with the new json(d) alarm, save it to the users device
            try jsonAlarm.write(to:createFileURLForPersistence() )
        } catch let encodingError{
            //Handel the error, if there is one
            print("There was an error saving!!! \(encodingError.localizedDescription) ")
        }}
        
        
        
        
    func loadFromPersistenceStore(){
        // the dada we want will be JSON, and i want it to be an alarm
        let jsonDecoder = JSONDecoder()
        // decode the data
        do {
            let jsonData = try Data(contentsOf: createFileURLForPersistence() )
            let decodedAlarms = try jsonDecoder.decode([Alarm].self, from:jsonData)
            alarms = decodedAlarms
        }catch let decodingError{
            print ("Therewas an error decoding!!\(decodingError.localizedDescription)")
        }
        }
}


    
